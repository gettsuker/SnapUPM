package CIT21_10.SnapUPM;

import org.junit.After;
import org.junit.Before;


import java.util.ArrayList;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;
import static org.junit.Assert.*;

public class UsuarioTest {
    Usuario usuario;
    Usuario usuario2 = mock(Usuario.class);
    @Before
    public void setUp() throws Exception {
         usuario = new Usuario(57, "angel", "ramirez","angel.R@alumnos.upm.es","paquitaSalas20",new ArrayList<Agenda>(),new ArrayList<IncorporacionAgenda>(),new ArrayList<Agrupacion>(),new ArrayList<MensajePersistente>(), new ArrayList<MensajePersistente>(), new Perfil());
    }

    @After
    public void tearDown() throws Exception {

    }

    @org.junit.Test
    public void constructor() {
    }

    @org.junit.Test
    public void destructor() {
    }

    @org.junit.Test
    public void iniciarSesion() {
    }

    @org.junit.Test
    public void cerrarSesion() {
    }

    @org.junit.Test
    public void recordarContrasena() {
    }

    @org.junit.Test
    public void getId() {
        assertEquals(57,usuario.getId());
    }

    @org.junit.Test
    public void setId() {
        usuario.setId(78);
        assertEquals(78,usuario.getId());
    }

    @org.junit.Test
    public void getNombre() {
        assertEquals("angel",usuario.getNombre());
    }

    @org.junit.Test
    public void setNombre() {
        usuario.setNombre("alejandro");
        assertEquals("alejandro",usuario.getNombre());
    }

    @org.junit.Test
    public void getApellido() {
        assertEquals("ramirez",usuario.getApellido());
    }

    @org.junit.Test
    public void setApellido() {
        usuario.setApellido("alcantara");
        assertEquals("alcantara",usuario.getApellido());
    }

    @org.junit.Test
    public void getCorreo() {
        assertEquals("angel.R@alumnos.upm.es",usuario.getCorreo());
    }

    @org.junit.Test
    public void setCorreo() {
        usuario.setCorreo("correo.cambiado@alumnos.upm.es");
        assertEquals("correo.cambiado@alumnos.upm.es",usuario.getCorreo());
    }

    @org.junit.Test
    public void getContrasena() {
        assertEquals("paquitaSalas20",usuario.getContrasena());
    }

    @org.junit.Test
    public void setContrasena() {
        usuario.setContrasena("contraCambiada");
        assertEquals("contraCambiada",usuario.getContrasena());
    }

    @org.junit.Test
    public void getAgendas() {

                assertEquals(  new ArrayList<Agenda>(),usuario.getAgendas());
    }

    @org.junit.Test
    public void setAgendas() {
        ArrayList<Agenda> agendas = new ArrayList<>();
        agendas.add(new Agenda());
        usuario.setAgendas(agendas);
        assertEquals(agendas, usuario.getAgendas());
    }

    @org.junit.Test
    public void getIncorporacionesAgenda() {
        assertEquals(new ArrayList<IncorporacionAgenda>(), usuario.getIncorporacionesAgenda());
    }

    @org.junit.Test
    public void setIncorporacionesAgenda() {
        ArrayList<IncorporacionAgenda> incorporaciones = new ArrayList<>();
        incorporaciones.add(new IncorporacionAgenda());
        usuario.setIncorporacionesAgenda(incorporaciones);
        assertEquals(incorporaciones, usuario.getIncorporacionesAgenda());
    }

    @org.junit.Test
    public void getAgrupacionesCreadas() {
        assertEquals(new ArrayList<Agrupacion>(), usuario.getAgrupacionesCreadas());
    }

    @org.junit.Test
    public void setAgrupacionesCreadas() {
        ArrayList<Agrupacion> agrupacionesCreadas = new ArrayList<>();
        agrupacionesCreadas.add(new Agrupacion());
        usuario.setAgrupacionesCreadas(agrupacionesCreadas);
        assertEquals(agrupacionesCreadas, usuario.getAgrupacionesCreadas());
    }

    @org.junit.Test
    public void getMensajesPersistentesEnviados() {
        assertEquals(new ArrayList<MensajePersistente>(), usuario.getMensajesPersistentesEnviados());
    }

    @org.junit.Test
    public void setMensajesPersistentesEnviados() {
        ArrayList<MensajePersistente> mensajePersistentesEnviados = new ArrayList<>();
        mensajePersistentesEnviados.add(new MensajePersistente());
        usuario.setMensajesPersistentesEnviados(mensajePersistentesEnviados);
        assertEquals(mensajePersistentesEnviados, usuario.getMensajesPersistentesEnviados());
    }

    @org.junit.Test
    public void getMensajesPersistentesRecibidos() {
        assertEquals(new ArrayList<MensajePersistente>(), usuario.getMensajesPersistentesRecibidos());
    }

    @org.junit.Test
    public void setMensajesPersistentesRecibidos() {
        ArrayList<MensajePersistente> mensajePersistentesRecibidos = new ArrayList<>();
        mensajePersistentesRecibidos.add(new MensajePersistente());
        usuario.setMensajesPersistentesEnviados(mensajePersistentesRecibidos);
        assertEquals(mensajePersistentesRecibidos, usuario.getMensajesPersistentesRecibidos());
    }

    @org.junit.Test
    public void getPerfilUsuario() {
        assertEquals(new Perfil(),usuario.getPerfilUsuario());
    }

    @org.junit.Test
    public void setPerfilUsuario() {
        usuario.setPerfilUsuario(new Perfil());
    }

    @org.junit.Test
    public void borrarAgenda() {
        doNothing().when(usuario2).borrarAgenda(12);
        usuario2.borrarAgenda(12);
        verify(usuario2,times(1)).borrarAgenda(12);
    }

    @org.junit.Test
    public void borradoCascadaTodasAgenda() {
        doNothing().when(usuario2).borradoCascadaTodasAgenda();
        usuario2.borradoCascadaTodasAgenda();
        verify(usuario2,times(1)).borradoCascadaTodasAgenda();
    }

    @org.junit.Test
    public void borrarIncorporacionAgenda() {
        doNothing().when(usuario2).borrarIncorporacionAgenda(12);
        usuario2.borrarIncorporacionAgenda(12);
        verify(usuario2,times(1)).borrarIncorporacionAgenda(12);
    }

    @org.junit.Test
    public void borrarAgrupacionCreada() {
        doNothing().when(usuario2).borrarAgrupacionCreada(12);
        usuario2.borrarAgrupacionCreada(12);
        verify(usuario2,times(1)).borrarAgrupacionCreada(12);
    }

    @org.junit.Test
    public void borrarMensajePersistenteEnviado() {
        doNothing().when(usuario2).borrarMensajePersistenteEnviado(12);
        usuario2.borrarMensajePersistenteEnviado(12);
        verify(usuario2,times(1)).borrarMensajePersistenteEnviado(12);
    }

    @org.junit.Test
    public void borrarMensajePersistenteRecibido() {
        doNothing().when(usuario2).borrarMensajePersistenteRecibido(12);
        usuario2.borrarAgenda(12);
        verify(usuario2,times(1)).borrarMensajePersistenteRecibido(12);
    }

    @org.junit.Test
    public void borrarPerfil() {
        doNothing().when(usuario2).borrarMensajePersistenteRecibido(12);
        usuario2.borrarMensajePersistenteRecibido(12);
        verify(usuario2,times(1)).borrarMensajePersistenteRecibido(12);
    }
}